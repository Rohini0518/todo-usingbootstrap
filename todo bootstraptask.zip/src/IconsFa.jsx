function IconsFa() {
  return (
    <div>
      <i className="fa-solid fa-pen"></i>
      <i className="fa-solid fa-trash"></i>
    </div>
  );
}

export default IconsFa;
