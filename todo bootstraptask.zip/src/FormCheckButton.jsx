import Form from "react-bootstrap/Form";

function FormCheckButton(props) {
  return <Form.Check aria-label="option 1" className="form-checkbox" />;
}
export default FormCheckButton;
