import "./App.css";
import ToDoTask from "./ToDoTask";

function App() {
  return (
    <div className="todo-container">
      <h2>TODO LIST</h2>
      <ToDoTask />
    </div>
  );
}

export default App;
